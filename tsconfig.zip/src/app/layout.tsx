import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getSiteSettings, getSiteIconUrl } from "@/lib/wordpress";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

export async function generateMetadata(): Promise<Metadata> {
  const [settings, iconUrl] = await Promise.all([
    getSiteSettings(),
    getSiteIconUrl(),
  ]);

  return {
    title: settings?.title || process.env.NEXT_PUBLIC_SITE_NAME || "Meu Blog WordPress",
    description: settings?.description || "Blog powered by WordPress + Next.js + GraphQL",
    icons: iconUrl
      ? { icon: iconUrl, shortcut: iconUrl, apple: iconUrl }
      : undefined,
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className={`${geistSans.variable} h-full antialiased`}>
      <body className="min-h-full flex flex-col bg-slate-50">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
